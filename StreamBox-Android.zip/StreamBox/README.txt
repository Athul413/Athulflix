Athulflix for Android
Upload this zip to GitHub as StreamBox-Android.zip and let the workflow build the APK.
