StreamBox for Android
1. Install Android Studio (Koala or newer).
2. File > Open > select this StreamBox folder, wait for Gradle sync.
3. Plug in a phone (USB debugging) or start an emulator, press Run.
4. For an installable APK: Build > Build Bundle(s)/APK(s) > Build APK(s).
