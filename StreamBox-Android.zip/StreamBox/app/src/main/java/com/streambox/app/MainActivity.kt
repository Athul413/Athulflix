package com.streambox.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Violet = Color(0xFF7C4DFF)
private val Pink = Color(0xFFF0509B)
private val Cyan = Color(0xFF22D3EE)
private val Ink = Color(0xFF0B0B12)
private val Glass = Color(0x14FFFFFF)
private val Line = Color(0x1CFFFFFF)
private val Mute = Color(0xFF9A9AB0)
private val Grad = Brush.linearGradient(listOf(Violet, Pink))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val incoming = intent?.dataString
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Ink)) {
                Home(incoming)
            }
        }
    }
}

@Composable
fun Home(incoming: String?) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val prefs = remember { ctx.getSharedPreferences("sb", 0) }
    var url by remember { mutableStateOf(incoming ?: "") }
    var status by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<String?>(null) }
    val history = remember {
        mutableStateListOf<String>().apply { addAll(prefs.getString("h", "")!!.split("\n").filter { it.isNotBlank() }) }
    }
    val player = remember { ExoPlayer.Builder(ctx).build() }

    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                status = "Can’t play this link (${error.errorCodeName}). Check the URL or format."
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) status = "Playing ✓"
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    fun play(u: String) {
        val t = u.trim()
        if (!t.startsWith("http", ignoreCase = true)) { status = "Enter a valid http(s) link"; return }
        url = t; current = t; status = "Connecting…"
        player.setMediaItem(MediaItem.fromUri(t)); player.prepare(); player.playWhenReady = true
        history.remove(t); history.add(0, t)
        while (history.size > 8) history.removeAt(history.lastIndex)
        prefs.edit().putString("h", history.joinToString("\n")).apply()
    }
    LaunchedEffect(Unit) { incoming?.let { play(it) } }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF1A1236), Ink, Color(0xFF07242C)))
        )
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Grad), contentAlignment = Alignment.Center) {
                    Text("▶", color = Color.White, fontSize = 14.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text("StreamBox", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            }
            Spacer(Modifier.height(22.dp))
            Text("Stream anything.", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp)
            Text(
                "Beautifully.", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp,
                style = TextStyle(brush = Brush.linearGradient(listOf(Violet, Pink, Cyan)), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            )
            Spacer(Modifier.height(8.dp))
            Text("Paste any MP4, MKV, WebM, HLS or DASH link.", color = Mute, fontSize = 15.sp)
            Spacer(Modifier.height(18.dp))

            OutlinedTextField(
                value = url, onValueChange = { url = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                placeholder = { Text("Paste a streaming link…", color = Mute) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { play(url) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Violet, unfocusedBorderColor = Line,
                    focusedContainerColor = Glass, unfocusedContainerColor = Glass,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Violet
                )
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Paste", Modifier.weight(1f)) {
                    clipboard.getText()?.text?.let { url = it.trim(); play(it) }
                }
                GradButton("▶  Play", Modifier.weight(2f)) { play(url) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("⚡ Sample HLS") { play("https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8") }
                Pill("⚡ Sample MP4") { play("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") }
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(status, color = if (status.startsWith("Can")) Color(0xFFFF6B7A) else Mute, fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))

            Box(
                Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(22.dp))
                    .border(2.dp, Grad, RoundedCornerShape(22.dp)).background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> PlayerView(c).apply { this.player = player; useController = true } }
                )
                if (current == null) Text("Paste a link above to start watching", color = Mute, fontSize = 14.sp)
            }
            Spacer(Modifier.height(14.dp))
            GradButton("⛶  Open Video Player", Modifier.fillMaxWidth()) {
                val u = current
                if (u == null) {
                    Toast.makeText(ctx, "Paste a link first", Toast.LENGTH_SHORT).show()
                } else {
                    player.pause()
                    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("url", u).putExtra("pos", player.currentPosition))
                }
            }

            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("RECENT LINKS", color = Mute, fontSize = 12.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) Text(
                    "CLEAR", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { history.clear(); prefs.edit().remove("h").apply() }
                )
            }
            Spacer(Modifier.height(10.dp))
            if (history.isEmpty()) Text("Your recent links will appear here.", color = Mute, fontSize = 14.sp)
            history.toList().forEach { u ->
                val uri = Uri.parse(u)
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(16.dp)).background(Glass)
                        .border(BorderStroke(1.dp, Line), RoundedCornerShape(16.dp)).clickable { play(u) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val hls = u.contains(".m3u8", true)
                    Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (hls) Grad else Brush.linearGradient(listOf(Violet, Cyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (hls) "HLS" else (uri.lastPathSegment?.substringAfterLast('.', "URL") ?: "URL").take(4).uppercase(),
                            color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(uri.lastPathSegment ?: u, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(uri.host ?: "", color = Mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("✕", color = Mute, modifier = Modifier.clickable {
                        history.remove(u); prefs.edit().putString("h", history.joinToString("\n")).apply()
                    }.padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun GradButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(50.dp).clip(RoundedCornerShape(14.dp)).background(Grad).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(50.dp).clip(RoundedCornerShape(14.dp)).background(Glass)
            .border(1.dp, Line, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 14.sp) }
}
