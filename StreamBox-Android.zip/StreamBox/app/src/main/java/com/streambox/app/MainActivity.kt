package com.streambox.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Violet = Color(0xFF7C4DFF)
private val Pink = Color(0xFFF0509B)
private val Cyan = Color(0xFF22D3EE)
private val Ink = Color(0xFF0B0B12)
private val Glass = Color(0x14FFFFFF)
private val Line = Color(0x1CFFFFFF)
private val Mute = Color(0xFF9A9AB0)
private val Grad = Brush.linearGradient(listOf(Violet, Pink))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val incoming = intent?.dataString
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = Ink)) {
                Home(incoming)
            }
        }
    }
}

@Composable
fun Logo(size: Dp) {
    Canvas(Modifier.size(size)) {
        val k = this.size.width / 108f
        drawRoundRect(brush = Grad, cornerRadius = CornerRadius(26f * k))
        val a = Path().apply {
            moveTo(54f * k, 24f * k); lineTo(86f * k, 84f * k); lineTo(72f * k, 84f * k)
            lineTo(54f * k, 48f * k); lineTo(36f * k, 84f * k); lineTo(22f * k, 84f * k); close()
        }
        drawPath(a, Color.White)
        val t = Path().apply { moveTo(47f * k, 66f * k); lineTo(47f * k, 80f * k); lineTo(61f * k, 73f * k); close() }
        drawPath(t, Color.White)
    }
}

/** Focus ring + slight zoom so the app is usable with a TV remote (D-pad). */
@Composable
fun Modifier.tvFocus(shape: Shape): Modifier {
    var f by remember { mutableStateOf(false) }
    return this
        .graphicsLayer { val s = if (f) 1.04f else 1f; scaleX = s; scaleY = s }
        .onFocusChanged { f = it.isFocused }
        .border(if (f) 3.dp else 0.dp, if (f) Color.White else Color.Transparent, shape)
}

@Composable
fun Home(incoming: String?) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val prefs = remember { ctx.getSharedPreferences("sb", 0) }
    var url by remember { mutableStateOf(incoming ?: "") }
    var status by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<String?>(null) }
    val history = remember {
        mutableStateListOf<String>().apply { addAll(prefs.getString("h", "")!!.split("\n").filter { it.isNotBlank() }) }
    }
    val player = remember { ExoPlayer.Builder(ctx).build() }

    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                status = "Can’t play this link (${error.errorCodeName}). Check the URL or format."
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) status = "Playing ✓"
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    fun play(u: String) {
        val t = u.trim()
        if (!t.startsWith("http", ignoreCase = true)) { status = "Enter a valid http(s) link"; return }
        url = t; current = t; status = "Connecting…"
        player.setMediaItem(MediaItem.fromUri(t)); player.prepare(); player.playWhenReady = true
        history.remove(t); history.add(0, t)
        while (history.size > 8) history.removeAt(history.lastIndex)
        prefs.edit().putString("h", history.joinToString("\n")).apply()
    }
    LaunchedEffect(Unit) { incoming?.let { play(it) } }

    var resumePos by remember { mutableStateOf(0L) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = r.data?.getLongExtra("pos", -1L) ?: -1L
        val u = current
        if (u != null) {
            player.setMediaItem(MediaItem.fromUri(u), if (p >= 0) p else resumePos)
            player.prepare(); player.play()
        }
    }
    fun openFullscreen() {
        val u = current
        if (u == null) Toast.makeText(ctx, "Paste a link first", Toast.LENGTH_SHORT).show()
        else {
            // Free the video decoder so the fullscreen player can use it
            resumePos = player.currentPosition
            player.stop(); player.clearMediaItems()
            launcher.launch(Intent(ctx, PlayerActivity::class.java).putExtra("url", u).putExtra("pos", resumePos))
        }
    }

    fun openExternal(name: String, pkgs: List<String>?) {
        val u = current
        if (u == null) { Toast.makeText(ctx, "Paste a link first", Toast.LENGTH_SHORT).show(); return }
        val type = if (u.contains(".m3u8", true)) "application/x-mpegURL" else "video/*"
        fun intent() = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), type)
            .putExtra("title", Uri.parse(u).lastPathSegment ?: "Athulflix")
        player.pause()
        if (pkgs == null) {
            try { ctx.startActivity(Intent.createChooser(intent(), "Open with")) }
            catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "No video player found", Toast.LENGTH_SHORT).show() }
            return
        }
        for (pkg in pkgs) {
            try { ctx.startActivity(intent().setPackage(pkg)); return } catch (e: ActivityNotFoundException) { }
        }
        Toast.makeText(ctx, "$name isn’t installed", Toast.LENGTH_LONG).show()
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A1236), Ink, Color(0xFF07242C))))
    ) {
        val wide = maxWidth >= 840.dp

        val brand: @Composable () -> Unit = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(40.dp)
                Spacer(Modifier.width(10.dp))
                Text("Athulflix", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
        }
        val hero: @Composable () -> Unit = {
            val fs = if (wide) 40.sp else 34.sp
            Text("Stream anything.", color = Color.White, fontSize = fs, fontWeight = FontWeight.ExtraBold, lineHeight = fs)
            Text(
                "Beautifully.", fontSize = fs, fontWeight = FontWeight.ExtraBold, lineHeight = fs,
                style = TextStyle(brush = Brush.linearGradient(listOf(Violet, Pink, Cyan)), fontSize = fs, fontWeight = FontWeight.ExtraBold)
            )
            Spacer(Modifier.height(8.dp))
            Text("Paste any MP4, MKV, WebM, HLS or DASH link.", color = Mute, fontSize = 15.sp)
        }
        val inputs: @Composable () -> Unit = {
            OutlinedTextField(
                value = url, onValueChange = { url = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                placeholder = { Text("Paste a streaming link…", color = Mute) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { play(url) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Violet, unfocusedBorderColor = Line,
                    focusedContainerColor = Glass, unfocusedContainerColor = Glass,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Violet
                )
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Paste", Modifier.weight(1f)) { clipboard.getText()?.text?.let { url = it.trim(); play(it) } }
                GradButton("▶  Play", Modifier.weight(2f)) { play(url) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("⚡ Sample HLS") { play("https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8") }
                Pill("⚡ Sample MP4") { play("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") }
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(status, color = if (status.startsWith("Can")) Color(0xFFFF6B7A) else Mute, fontSize = 13.sp)
            }
        }
        val playerCard: @Composable () -> Unit = {
            Box(
                Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(22.dp))
                    .border(2.dp, Grad, RoundedCornerShape(22.dp)).background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> PlayerView(c).apply { this.player = player; useController = true; setFullscreenButtonClickListener { openFullscreen() } } }
                )
                if (current == null) Text("Paste a link above to start watching", color = Mute, fontSize = 14.sp)
            }
            Spacer(Modifier.height(14.dp))
            GradButton("⛶  Open Video Player", Modifier.fillMaxWidth()) { openFullscreen() }
            Spacer(Modifier.height(14.dp))
            Text("OPEN LINK IN", color = Mute, fontSize = 12.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("VLC", Modifier.weight(1f)) { openExternal("VLC", listOf("org.videolan.vlc")) }
                Pill("Nova", Modifier.weight(1f)) { openExternal("Nova Player", listOf("org.courville.nova", "com.archos.mediacenter.videofree")) }
                Pill("Other…", Modifier.weight(1f)) { openExternal("", null) }
            }
        }
        val historyBlock: @Composable () -> Unit = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("RECENT LINKS", color = Mute, fontSize = 12.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) Text(
                    "CLEAR", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.tvFocus(RoundedCornerShape(8.dp)).clickable { history.clear(); prefs.edit().remove("h").apply() }.padding(4.dp)
                )
            }
            Spacer(Modifier.height(10.dp))
            if (history.isEmpty()) Text("Your recent links will appear here.", color = Mute, fontSize = 14.sp)
            history.toList().forEach { u ->
                val uri = Uri.parse(u)
                val shape = RoundedCornerShape(16.dp)
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).tvFocus(shape).clip(shape).background(Glass)
                        .border(1.dp, Line, shape).clickable { play(u) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val hls = u.contains(".m3u8", true)
                    Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (hls) Grad else Brush.linearGradient(listOf(Violet, Cyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (hls) "HLS" else (uri.lastPathSegment?.substringAfterLast('.', "URL") ?: "URL").take(4).uppercase(),
                            color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(uri.lastPathSegment ?: u, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(uri.host ?: "", color = Mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("✕", color = Mute, modifier = Modifier.clickable {
                        history.remove(u); prefs.edit().putString("h", history.joinToString("\n")).apply()
                    }.padding(8.dp))
                }
            }
        }

        if (wide) {
            // TV / tablet / landscape: big player on the left, controls on the right
            Row(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 48.dp, vertical = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(36.dp)
            ) {
                Column(Modifier.weight(1.7f).verticalScroll(rememberScrollState())) {
                    brand(); Spacer(Modifier.height(20.dp)); playerCard()
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    hero(); Spacer(Modifier.height(18.dp)); inputs(); Spacer(Modifier.height(24.dp)); historyBlock()
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                brand(); Spacer(Modifier.height(22.dp)); hero(); Spacer(Modifier.height(18.dp)); inputs()
                Spacer(Modifier.height(16.dp)); playerCard(); Spacer(Modifier.height(26.dp)); historyBlock()
            }
        }
    }
}

@Composable
fun GradButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.height(50.dp).tvFocus(shape).clip(shape).background(Grad).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.height(50.dp).tvFocus(shape).clip(shape).background(Glass)
            .border(1.dp, Line, shape).clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 14.sp) }
}
