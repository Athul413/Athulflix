package com.streambox.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** Full-screen theater player: immersive, landscape, keeps screen awake. */
class PlayerActivity : ComponentActivity() {
    private var exo: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        val p = ExoPlayer.Builder(this).build().also { exo = it }
        p.setMediaItem(MediaItem.fromUri(url))
        p.seekTo(intent.getLongExtra("pos", 0L))
        p.prepare()
        p.playWhenReady = true
        setContentView(PlayerView(this).apply {
            isFocusable = true
            requestFocus()
            player = p
            setBackgroundColor(Color.BLACK)
            setShowSubtitleButton(true)
            controllerShowTimeoutMs = 3000
            setFullscreenButtonClickListener { finish() }
        })
    }

    override fun finish() {
        exo?.let { setResult(RESULT_OK, Intent().putExtra("pos", it.currentPosition)) }
        super.finish()
    }

    override fun onStop() { super.onStop(); exo?.pause() }
    override fun onDestroy() { super.onDestroy(); exo?.release(); exo = null }
}
